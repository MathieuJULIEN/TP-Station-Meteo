module StationMeteo

go 1.27.4
